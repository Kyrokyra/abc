#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach-o/nlist.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

// ReoFix: ảnh bìa KHÔNG vuông (vd. thumbnail YouTube 16:9) -> bỏ nền/viền, bo góc theo ảnh.
// Ảnh vuông (Spotify, bìa album) -> giữ đúng kiểu gốc của Reo.
// Khung thông tin được kéo rộng cho mọi bài. Không đụng vào view của NextUp.
//
// v0.1.0 — sửa theo số đo thật (reofix_tree_open.txt / reofix_state.txt):
//  * Reo.minimizeMiniPlayer là hàm "đi xuống một bậc": lớn -> nhỏ, NHỎ -> ẨN (dismissed). Bản cũ gọi nó
//    khi player đã nhỏ nên player bị ẩn. Giờ chỉ "bấm vào ảnh bìa" (hideReoView, đúng như ngón tay) và
//    chỉ khi đọc được trạng thái thật của Reo (_minimized/_dismissed/_hidingReo) cho phép.
//  * Toạ độ không còn dựa vào view.window (lúc dump window = nil nên convertRect:toView:nil trả y nguyên).
//  * Trạng thái "đang mở thông báo" suy ra từ NCNotificationListCell nhìn thấy, không tin cờ chọn của Axon.
//  * Player dịch lên thì vùng chạm cũng phải dịch theo (pointInside).

@interface ReoContainerView : UIView
@end

@interface NCNotificationListView : UIView
@end

static void ReoFixContainer(UIView *container);   // khai báo trước
static void ReoDumpState(void);              // khai báo trước
static const void *kReoBtnOrigKey    = &kReoBtnOrigKey;     // frame gốc của nút bấm ảnh
static const void *kReoBtnAppliedKey = &kReoBtnAppliedKey;  // frame nút bấm mình đã đặt

// Con trỏ yếu tới container Reo đang dùng
static __weak UIView *gReoContainer;
static BOOL gAxonTouched = NO;        // vừa chạm icon Axon (chờ thông báo hiện ra)
static CFTimeInterval gAxonEventTime = 0;   // lần cuối Axon gọi select/deselect
static BOOL gNotifOpen = NO;          // thông báo đang mở dưới player (đo từ cell nhìn thấy)
static BOOL gMinimizedByUs = NO;      // chính ReoFix đã thu nhỏ player -> sau này mới được phóng lại
static BOOL gNotifFixPending = NO;    // gộp các lần layout của danh sách thông báo
static double gSig = 0;               // "chữ ký" hình học của lần tính gần nhất: đổi = còn đang chuyển động
static CFTimeInterval gLastChange = 0;     // lần cuối hình học đổi
static CFTimeInterval gAutoDeadline = 0;   // hạn cố gắng tự thu nhỏ (tính từ lúc thông báo mở)
static CFTimeInterval gLastTap = 0;        // lần cuối ReoFix bấm vào ảnh bìa
static int gAutoTaps = 0;
static BOOL gAutoBusy = NO;
static BOOL gWatching = NO;           // đang canh định kỳ khi thông báo mở
static CFTimeInterval gLastLiftLog = 0;
static CGFloat gLastLiftLogged = -1;
static CGFloat gDbgWant = 0, gDbgMaxLift = 0, gDbgRowExtra = 0, gDbgNTop = 0;   // số liệu lần tính lift gần nhất
static CGRect gDbgBfs;
static BOOL gDbgHide = NO;
static NSMutableArray *gLog;
static BOOL gLogFlushPending = NO;
static BOOL ReoReoHiding(void);        // khai báo trước (định nghĩa sau ReoReadState)

// Nhật ký sự kiện (giữ 160 dòng cuối) -> /var/mobile/Documents/reofix_log.txt và cuối reofix_state.txt
static void ReoLogFlush(void) {
    gLogFlushPending = NO;
    if (!gLog) return;
    NSString *all = [gLog componentsJoinedByString:@"\n"];
    [all writeToFile:@"/var/mobile/Documents/reofix_log.txt" atomically:NO encoding:NSUTF8StringEncoding error:nil];
}
static void ReoLog(NSString *fmt, ...) __attribute__((format(__NSString__, 1, 2)));
static void ReoLog(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *s = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    if (!gLog) gLog = [NSMutableArray array];
    [gLog addObject:[NSString stringWithFormat:@"%8.2f  %@", fmod(CACurrentMediaTime(), 100000.0), s]];
    while (gLog.count > 160) [gLog removeObjectAtIndex:0];
    if (!gLogFlushPending) {
        gLogFlushPending = YES;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ ReoLogFlush(); });
    }
}

@interface ReoWeakBox : NSObject
@property (nonatomic, weak) UIView *v;
@end
@implementation ReoWeakBox
@end

static const void *kReoClearKey     = &kReoClearKey;      // view/layer đã bị làm trong suốt
static const void *kReoSavedKey     = &kReoSavedKey;      // trạng thái gốc (lưu trên layer)
static const void *kReoModeKey      = &kReoModeKey;       // contentMode gốc của ảnh
static const void *kReoBoxKey       = &kReoBoxKey;        // trỏ về ReoContainerView
static const void *kReoOrigFrameKey = &kReoOrigFrameKey;  // frame gốc của khung thông tin
static const void *kReoAppliedKey   = &kReoAppliedKey;    // frame mình đã đặt
static const void *kReoArtOrigKey    = &kReoArtOrigKey;     // frame gốc của ảnh bìa
static const void *kReoArtAppliedKey = &kReoArtAppliedKey;  // frame ảnh mình đã đặt
static const void *kReoWidenUsedKey  = &kReoWidenUsedKey;   // độ rộng thêm đã dùng
static const void *kReoNextUpKey     = &kReoNextUpKey;      // hàng Next Up đã gắn vào player
static const void *kReoRecheckKey    = &kReoRecheckKey;     // đã hẹn kiểm tra lại vị trí
static BOOL gInRecheck = NO;
static const void *kReoLiftOrigKey    = &kReoLiftOrigKey;     // frame gốc trước khi dịch lên
static const void *kReoLiftAppliedKey = &kReoLiftAppliedKey;  // frame sau khi dịch lên
static const void *kReoLiftValueKey   = &kReoLiftValueKey;    // độ dịch lên hiện tại

// Bám theo hiệu ứng trượt của thông báo: tính lại vị trí MỖI KHUNG HÌNH trong vài giây
@interface ReoTicker : NSObject
@property (nonatomic, weak) UIView *container;
@property (nonatomic) CFTimeInterval until;
@property (nonatomic, strong) CADisplayLink *link;
@end
static ReoTicker *gTicker;
@implementation ReoTicker
- (void)tick:(CADisplayLink *)l {
    UIView *c = self.container;
    if (!c || CACurrentMediaTime() > self.until) {
        [l invalidate];
        self.link = nil;
        gTicker = nil;
        return;
    }
    double before = gSig;
    gInRecheck = YES;
    ReoFixContainer(c);
    gInRecheck = NO;
    // Còn chuyển động (hình học đổi, hoặc Reo đang chạy hiệu ứng) thì cứ bám tiếp; đứng yên 0.6 s mới dừng.
    if (fabs(gSig - before) > 0.01 || ReoReoHiding()) {
        CFTimeInterval u = CACurrentMediaTime() + 0.6;
        if (u > self.until) self.until = u;
    }
}
@end
static void ReoFollow(UIView *container, double seconds) {
    if (!container) return;
    if (gTicker) {
        CFTimeInterval u = CACurrentMediaTime() + seconds;
        if (u > gTicker.until) gTicker.until = u;
        return;
    }
    ReoTicker *t = [ReoTicker new];
    t.container = container;
    t.until = CACurrentMediaTime() + seconds;
    t.link = [CADisplayLink displayLinkWithTarget:t selector:@selector(tick:)];
    [t.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    gTicker = t;
}


static id ReoIvar(id obj, const char *name) {
    Ivar iv = class_getInstanceVariable(object_getClass(obj), name);
    return iv ? object_getIvar(obj, iv) : nil;
}

static CGFloat ReoCornerRadius(void) {
    CGFloat r = 15;
    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("CornerRadius"),
                                                    CFSTR("com.mystery.reopreferences"));
    if (v) {
        if (CFGetTypeID(v) == CFNumberGetTypeID()) {
            double d = 15;
            CFNumberGetValue((CFNumberRef)v, kCFNumberDoubleType, &d);
            r = d;
        }
        CFRelease(v);
    }
    return r;
}

// Cài đặt của ReoFix (Cài đặt > ReoFix)
static CGFloat ReoPrefNumber(CFStringRef key, CGFloat def) {
    CGFloat r = def;
    CFPropertyListRef v = CFPreferencesCopyAppValue(key, CFSTR("com.local.reofix"));
    if (v) {
        if (CFGetTypeID(v) == CFNumberGetTypeID()) {
            double d = def;
            CFNumberGetValue((CFNumberRef)v, kCFNumberDoubleType, &d);
            r = d;
        }
        CFRelease(v);
    }
    return r;
}
static BOOL ReoPrefBool(CFStringRef key, BOOL def) {
    BOOL r = def;
    CFPropertyListRef v = CFPreferencesCopyAppValue(key, CFSTR("com.local.reofix"));
    if (v) {
        if (CFGetTypeID(v) == CFBooleanGetTypeID()) r = CFBooleanGetValue((CFBooleanRef)v);
        else if (CFGetTypeID(v) == CFNumberGetTypeID()) {
            int n = 0; CFNumberGetValue((CFNumberRef)v, kCFNumberIntType, &n); r = n != 0;
        }
        CFRelease(v);
    }
    return r;
}

// ---------------------------------------------------------------------------------------------
// Toạ độ màn hình KHÔNG phụ thuộc view.window: cộng dồn (frame.origin - bounds.origin) từ view lên tới
// gốc cây view. bounds.origin của UIScrollView chính là contentOffset nên danh sách thông báo (offset
// -336) được tính đúng. r nằm trong hệ toạ độ của v.
// ---------------------------------------------------------------------------------------------
static CGRect ReoScreenRect(UIView *v, CGRect r) {
    int guard = 0;
    for (UIView *cur = v; cur && guard < 64; cur = cur.superview, guard++) {
        r.origin.x += cur.frame.origin.x - cur.bounds.origin.x;
        r.origin.y += cur.frame.origin.y - cur.bounds.origin.y;
    }
    return r;
}
// frame của v (nằm trong superview) theo toạ độ màn hình
static CGRect ReoScreenFrame(UIView *v) {
    return v.superview ? ReoScreenRect(v.superview, v.frame) : v.frame;
}
static BOOL ReoChainVisible(UIView *v) {
    for (UIView *p = v; p; p = p.superview) {
        if (p.hidden || p.alpha < 0.05) return NO;
    }
    return YES;
}

// ---------------------------------------------------------------------------------------------
// Đọc trạng thái thật của Reo: các biến static _minimized / _dismissed / _hidingReo nằm trong bảng
// symbol của Reo.dylib (symbol cục bộ, dlsym không thấy). Địa chỉ khác nhau giữa arm64 và arm64e và
// giữa các bản Reo, nên tra bảng symbol của image đang nạp thay vì dùng offset cố định.
// Không tìm được thì trả known = NO và ReoFix dùng số đo hình học thay thế.
// ---------------------------------------------------------------------------------------------
static const struct mach_header_64 *gReoHdr = NULL;
static intptr_t gReoSlide = 0;
static const unsigned char *gRMin = NULL, *gRDis = NULL, *gRHid = NULL;
static BOOL gRResolved = NO;

static void ReoLocateImage(void) {
    if (gReoHdr) return;
    static CFAbsoluteTime last = 0;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (last != 0 && now - last < 2.0) return;
    last = now;
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; i++) {
        const char *nm = _dyld_get_image_name(i);
        if (!nm) continue;
        const char *base = strrchr(nm, '/');
        base = base ? base + 1 : nm;
        if (strcmp(base, "Reo.dylib") == 0) {
            const struct mach_header_64 *h = (const struct mach_header_64 *)_dyld_get_image_header(i);
            if (h && h->magic == MH_MAGIC_64) {
                gReoSlide = _dyld_get_image_vmaddr_slide(i);
                gReoHdr = h;
            }
            return;
        }
    }
}

// Địa chỉ phải nằm trong một segment __DATA* của Reo
static BOOL ReoAddrInReoData(uintptr_t a) {
    const struct mach_header_64 *h = gReoHdr;
    const struct load_command *lc = (const struct load_command *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++) {
        if (lc->cmdsize < sizeof(struct load_command)) return NO;
        if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *sg = (const struct segment_command_64 *)lc;
            if (strncmp(sg->segname, "__DATA", 6) == 0) {
                uintptr_t lo = (uintptr_t)gReoSlide + (uintptr_t)sg->vmaddr;
                if (a >= lo && a < lo + (uintptr_t)sg->vmsize) return YES;
            }
        }
        lc = (const struct load_command *)((const char *)lc + lc->cmdsize);
    }
    return NO;
}

// Tìm symbol cục bộ theo tên (có dấu _ đứng đầu) trong bảng symbol của Reo; NULL nếu không thấy
static const unsigned char *ReoSymAddr(const char *name) {
    const struct mach_header_64 *h = gReoHdr;
    if (!h) return NULL;
    const struct symtab_command *st = NULL;
    const struct segment_command_64 *le = NULL;
    const struct load_command *lc = (const struct load_command *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++) {
        if (lc->cmdsize < sizeof(struct load_command)) return NULL;
        if (lc->cmd == LC_SYMTAB) {
            st = (const struct symtab_command *)lc;
        } else if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *sg = (const struct segment_command_64 *)lc;
            if (strncmp(sg->segname, "__LINKEDIT", 16) == 0) le = sg;
        }
        lc = (const struct load_command *)((const char *)lc + lc->cmdsize);
    }
    if (!st || !le) return NULL;
    // kiểm tra bảng symbol và bảng chuỗi nằm gọn trong __LINKEDIT
    uint64_t leEnd = (uint64_t)le->fileoff + le->filesize;
    if (st->symoff < le->fileoff || (uint64_t)st->symoff + (uint64_t)st->nsyms * sizeof(struct nlist_64) > leEnd) return NULL;
    if (st->stroff < le->fileoff || (uint64_t)st->stroff + st->strsize > leEnd) return NULL;
    uintptr_t linkBase = (uintptr_t)gReoSlide + (uintptr_t)le->vmaddr - (uintptr_t)le->fileoff;
    const struct nlist_64 *nl = (const struct nlist_64 *)(linkBase + st->symoff);
    const char *strs = (const char *)(linkBase + st->stroff);
    size_t want = strlen(name);
    for (uint32_t i = 0; i < st->nsyms; i++) {
        uint32_t off = nl[i].n_un.n_strx;
        if (off == 0 || off >= st->strsize) continue;
        if (nl[i].n_type & N_STAB) continue;
        if ((nl[i].n_type & N_TYPE) != N_SECT) continue;
        if (off + want + 1 > st->strsize) continue;
        if (strcmp(strs + off, name) != 0) continue;
        uintptr_t a = (uintptr_t)nl[i].n_value + (uintptr_t)gReoSlide;
        return ReoAddrInReoData(a) ? (const unsigned char *)a : NULL;
    }
    return NULL;
}

typedef struct { BOOL known; BOOL minimized; BOOL dismissed; BOOL hiding; } ReoState;

static ReoState ReoReadState(void) {
    ReoState s = {NO, NO, NO, NO};
    if (!gRResolved) {
        ReoLocateImage();
        if (!gReoHdr) return s;                 // Reo chưa nạp: lần sau thử lại
        gRMin = ReoSymAddr("_minimized");
        gRDis = ReoSymAddr("_dismissed");
        gRHid = ReoSymAddr("_hidingReo");
        gRResolved = YES;
    }
    if (gRMin && gRDis) {
        s.known = YES;
        s.minimized = (*gRMin != 0);
        s.dismissed = (*gRDis != 0);
        s.hiding = gRHid ? (*gRHid != 0) : NO;
    }
    return s;
}

static BOOL ReoReoHiding(void) {
    ReoState s = ReoReadState();
    return s.known && s.hiding;
}

static BOOL ReoIsMarked(id o) { return objc_getAssociatedObject(o, kReoClearKey) != nil; }

// Làm trong suốt + lưu trạng thái gốc để trả lại sau
static void ReoMarkClear(UIView *v) {
    CALayer *l = v.layer;
    if (!ReoIsMarked(v)) {
        NSMutableDictionary *d = [NSMutableDictionary dictionary];
        if (v.backgroundColor) d[@"bg"] = v.backgroundColor;
        d[@"bw"]  = @(l.borderWidth);
        d[@"cr"]  = @(l.cornerRadius);
        d[@"mtb"] = @(l.masksToBounds);
        objc_setAssociatedObject(l, kReoSavedKey, d, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(v, kReoClearKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(l, kReoClearKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    v.backgroundColor = [UIColor clearColor];
    l.backgroundColor = NULL;
    l.borderWidth = 0;
    l.cornerRadius = 0;
    l.masksToBounds = NO;
}

// Trả lại đúng như Reo đặt
static void ReoUnmark(UIView *v) {
    if (!ReoIsMarked(v)) return;
    CALayer *l = v.layer;
    NSDictionary *d = objc_getAssociatedObject(l, kReoSavedKey);
    objc_setAssociatedObject(v, kReoClearKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(l, kReoClearKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(l, kReoSavedKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    UIColor *bg = d[@"bg"] ?: d[@"lbg"];
    v.backgroundColor = bg;
    l.borderWidth = [d[@"bw"] doubleValue];
    l.cornerRadius = [d[@"cr"] doubleValue];
    l.masksToBounds = [d[@"mtb"] boolValue];
    l.mask = nil;
}

// View của tweak NextUp (NUNextUpRowView...): tuyệt đối không đụng vào
static BOOL ReoIsNextUpClass(UIView *v) {
    const char *n = class_getName(object_getClass(v));
    return n && strncmp(n, "NU", 2) == 0;
}
static BOOL ReoHasNextUp(UIView *v, int depth) {
    if (ReoIsNextUpClass(v)) return YES;
    if (depth <= 0) return NO;
    for (UIView *s in v.subviews) {
        if (ReoHasNextUp(s, depth - 1)) return YES;
    }
    return NO;
}

// ---------------------------------------------------------------------------------------------
// Giữ vị trí đã chỉnh. Reo (hàm của nó hook ở nơi khác, ReoContainerView không tự layout) và hiệu ứng của
// nó có thể đặt lại frame của view con SAU lượt tính của ReoFix; khi đó phần đã chỉnh (ảnh, khung thông
// tin, dịch lên) mất cho tới lần layout kế tiếp. Hook setFrame: chỉ để phát hiện "ai đó khác ReoFix đặt
// frame khác với frame ReoFix đã đặt" trên các view con TRỰC TIẾP của container, rồi chạy lại một lượt
// (gộp, tối đa ~20 lần/giây). Trong lúc ReoFix đang tính (gPassDepth > 0) thì bỏ qua để khỏi lặp vô tận.
// ---------------------------------------------------------------------------------------------
static int gPassDepth = 0;
static unsigned gPassCount = 0;
static unsigned gGuardHits = 0;
static BOOL gGuardPending = NO;
static CFTimeInterval gGuardLast = 0;
static void *gReoContainerPtr = NULL;     // chỉ để so sánh con trỏ, không giữ đối tượng

static void ReoGuardSchedule(void) {
    if (gGuardPending) return;
    gGuardPending = YES;
    double wait = gGuardLast + 0.05 - CACurrentMediaTime();
    if (wait < 0) wait = 0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(wait * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        gGuardPending = NO;
        gGuardLast = CACurrentMediaTime();
        UIView *c = gReoContainer;
        if (c && c.superview) ReoFixContainer(c);
    });
}

static void ReoGuardCheck(UIView *v, CGRect nf) {
    if (ReoIsNextUpClass(v)) return;
    NSValue *a = objc_getAssociatedObject(v, kReoLiftAppliedKey);
    if (!a) a = objc_getAssociatedObject(v, kReoArtAppliedKey);
    if (!a) a = objc_getAssociatedObject(v, kReoAppliedKey);
    if (!a) a = objc_getAssociatedObject(v, kReoBtnAppliedKey);
    if (!a || CGRectEqualToRect([a CGRectValue], nf)) return;
    gGuardHits++;
    if (gGuardHits <= 12) {
        ReoLog(@"OVERWRITE %@ new=%@ ours=%@", NSStringFromClass([v class]), NSStringFromCGRect(nf),
               NSStringFromCGRect([a CGRectValue]));
    }
    ReoGuardSchedule();
}

static BOOL ReoClose(CGRect a, CGRect b) {
    return fabs(a.origin.x - b.origin.x) < 6 && fabs(a.origin.y - b.origin.y) < 6 &&
           fabs(a.size.width - b.size.width) < 6 && fabs(a.size.height - b.size.height) < 6;
}

static void ReoCollectImageViews(UIView *v, NSMutableArray *out) {
    for (UIView *s in v.subviews) {
        if (ReoIsNextUpClass(s)) continue;
        if ([s isKindOfClass:[UIImageView class]] &&
            s.bounds.size.width >= 120 && ((UIImageView *)s).image) {
            [out addObject:s];
        }
        ReoCollectImageViews(s, out);
    }
}

// Bo góc đúng vùng ảnh thật (aspect-fit) bằng mask
static void ReoRoundImageRect(UIImageView *iv) {
    if (ReoHasNextUp(iv, 2)) return;
    CGSize is = iv.image.size, bs = iv.bounds.size;
    if (is.width <= 0 || is.height <= 0 || bs.width <= 0 || bs.height <= 0) return;
    CGFloat sc = MIN(bs.width / is.width, bs.height / is.height);
    CGSize fit = CGSizeMake(is.width * sc, is.height * sc);
    CGRect r = CGRectMake((bs.width - fit.width) / 2, (bs.height - fit.height) / 2,
                          fit.width, fit.height);
    CGFloat radius = MIN(ReoCornerRadius(), MIN(fit.width, fit.height) / 2);
    CAShapeLayer *m = [CAShapeLayer layer];
    m.path = [UIBezierPath bezierPathWithRoundedRect:r cornerRadius:radius].CGPath;
    iv.layer.mask = m;
}

static BOOL ReoAlreadyApplied(UIView *v) {
    NSValue *a = objc_getAssociatedObject(v, kReoAppliedKey);
    return a && CGRectEqualToRect(v.frame, [a CGRectValue]);
}

// Khung thông tin: kéo rộng ra hai bên (áp dụng cho mọi bài)
static void ReoReshapePanel(UIView *container, BOOL apply) {
    UIView *bg = ReoIvar(container, "_reoMiniBackgroundView");
    if (![bg isKindOfClass:[UIView class]] || !bg.superview) return;
    if (!apply) {
        NSValue *o = objc_getAssociatedObject(bg, kReoOrigFrameKey);
        if (o && ReoAlreadyApplied(bg)) bg.frame = [o CGRectValue];
        objc_setAssociatedObject(bg, kReoOrigFrameKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(bg, kReoAppliedKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return;
    }
    CGFloat want = ReoPrefNumber(CFSTR("panelWiden"), 12);
    CGRect f = bg.frame;
    if (ReoAlreadyApplied(bg)) {
        NSNumber *used = objc_getAssociatedObject(bg, kReoWidenUsedKey);
        NSValue *o = objc_getAssociatedObject(bg, kReoOrigFrameKey);
        if (!o || (used && fabs(used.doubleValue - want) < 0.5)) return;
        f = [o CGRectValue];            // giá trị đổi -> tính lại từ frame gốc
    }
    if (f.size.width < container.bounds.size.width * 0.5 || f.size.height < 130) return;
    objc_setAssociatedObject(bg, kReoOrigFrameKey, [NSValue valueWithCGRect:f],
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    CGFloat d = MIN(want, MAX(0, f.origin.x - 6));
    f.origin.x -= d;
    f.size.width += 2 * d;
    bg.frame = f;
    objc_setAssociatedObject(bg, kReoAppliedKey, [NSValue valueWithCGRect:bg.frame],
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(bg, kReoWidenUsedKey, @(want), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

// Thu nhỏ từ phía trên cho đỉnh >= limit (giữ đáy, tâm ngang, tỉ lệ)
static CGRect ReoShrinkTop(CGRect t, CGFloat limit) {
    CGFloat over = limit - t.origin.y;
    if (over <= 0 || t.size.height - over < 80) return t;
    CGFloat newH = t.size.height - over;
    CGFloat newW = t.size.width * newH / t.size.height;
    return CGRectMake(CGRectGetMidX(t) - newW / 2, CGRectGetMaxY(t) - newH, newW, newH);
}

// Thu nhỏ theo chiều rộng (giữ đáy, tâm ngang, tỉ lệ)
static CGRect ReoScaleWidthKeepBottom(CGRect t, CGFloat newW) {
    CGFloat newH = t.size.height * newW / t.size.width;
    return CGRectMake(CGRectGetMidX(t) - newW / 2, CGRectGetMaxY(t) - newH, newW, newH);
}

// Tìm view theo đúng tên class, duyệt tối đa `depth` cấp
static UIView *ReoFindByClass(UIView *root, const char *cls, int depth) {
    for (UIView *sv in root.subviews) {
        const char *n = class_getName(object_getClass(sv));
        if (n && strcmp(n, cls) == 0) return sv;
        if (depth > 0) {
            UIView *r = ReoFindByClass(sv, cls, depth - 1);
            if (r) return r;
        }
    }
    return nil;
}

// Danh sách thông báo GỐC: nằm cạnh ReoContainerView trong cùng view cha (theo cây view thật)
static UIView *ReoNotifRoot(void) {
    UIView *parent = gReoContainer.superview;
    Class ncl = objc_getClass("NCNotificationListView");
    if (!parent || !ncl) return nil;
    for (UIView *sv in parent.subviews) {
        if ([sv isKindOfClass:ncl]) return sv;
    }
    return nil;
}

// Hàng icon Axon: nằm trong danh sách thông báo gốc (UIStackView > AXNView)
static UIView *ReoAxonView(void) {
    UIView *root = ReoNotifRoot();
    if (!root) return nil;
    return ReoFindByClass(root, "AXNView", 4);
}

// Đáy đồng hồ (toạ độ màn hình). iOS 16: đồng hồ do PosterBoard vẽ, không có trong cây view của
// SpringBoard nên không đo được -> lấy số trong Cài đặt (mặc định 216 theo ảnh chụp của bạn).
static CGFloat ReoClockBottom(void) {
    return ReoPrefNumber(CFSTR("clockBottom"), 216);
}

// Vùng (toạ độ màn hình) của các icon Axon (AXNAppCell) đang nhìn thấy; CGRectNull nếu không có icon nào
static CGRect ReoAxonIconsRect(void) {
    UIView *av = ReoAxonView();
    CGRect u = CGRectNull;
    if (!av || !ReoChainVisible(av)) return u;
    CGFloat sh = [UIScreen mainScreen].bounds.size.height;
    for (UIView *cv in av.subviews) {                 // UICollectionView
        for (UIView *cell in cv.subviews) {
            if (cell.hidden || cell.alpha < 0.05) continue;
            const char *n = class_getName(object_getClass(cell));
            if (!n || !strstr(n, "AXNAppCell")) continue;
            u = CGRectUnion(u, ReoScreenRect(cv, cell.frame));
        }
    }
    if (!CGRectIsNull(u) && (CGRectGetMaxY(u) <= 0 || u.origin.y >= sh)) return CGRectNull;   // ngoài màn hình
    return u;
}

// Giữ ảnh không đè lên đồng hồ và icon thông báo của Axon (tự thu nhỏ vừa đủ)
static CGRect ReoClampArtwork(UIView *iv, CGRect target) {
    if (!iv.superview) return target;
    CGRect t = ReoScreenRect(iv.superview, target);
    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    if (ReoPrefBool(CFSTR("avoidClock"), YES)) t = ReoShrinkTop(t, ReoClockBottom() + 6);

    if (ReoPrefBool(CFSTR("avoidAxon"), YES)) {
        CGRect o = ReoAxonIconsRect();
        if (!CGRectIsNull(o) && CGRectIntersectsRect(CGRectInset(o, -4, -4), t)) {
            BOOL handled = NO;
            CGFloat midX = CGRectGetMidX(t);
            if (CGRectGetMaxX(o) < sw * 0.35) {            // icon sát mép trái -> chừa chỗ bên trái
                CGFloat w2 = 2 * (midX - (CGRectGetMaxX(o) + 8));
                if (w2 >= 200 && w2 < t.size.width) { t = ReoScaleWidthKeepBottom(t, w2); handled = YES; }
            } else if (CGRectGetMinX(o) > sw * 0.65) {     // icon sát mép phải
                CGFloat w2 = 2 * ((CGRectGetMinX(o) - 8) - midX);
                if (w2 >= 200 && w2 < t.size.width) { t = ReoScaleWidthKeepBottom(t, w2); handled = YES; }
            }
            if (!handled) t = ReoShrinkTop(t, CGRectGetMaxY(o) + 8);   // không thì cho ảnh nằm dưới hàng icon
        }
    }
    CGRect off = ReoScreenRect(iv.superview, CGRectZero);
    return CGRectOffset(t, -off.origin.x, -off.origin.y);
}

static void ReoProcessImage(UIView *container, UIImageView *iv, BOOL apply, BOOL maximized) {
    // A) Trả khung ảnh về đúng như Reo đặt, để dò khung bao quanh theo vị trí gốc
    NSValue *ap0 = objc_getAssociatedObject(iv, kReoArtAppliedKey);
    NSValue *or0 = objc_getAssociatedObject(iv, kReoArtOrigKey);
    if (ap0 && or0 && CGRectEqualToRect(iv.frame, [ap0 CGRectValue])) {
        iv.frame = [or0 CGRectValue];
    }
    objc_setAssociatedObject(iv, kReoArtAppliedKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(iv, kReoArtOrigKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    CGRect orig = iv.frame;

    // B) Các khung bao quanh ảnh
    NSMutableArray *chain = [NSMutableArray arrayWithObject:iv];
    for (UIView *p = iv.superview; p && p != container; p = p.superview) {
        if (CGRectGetWidth(p.bounds) > CGRectGetWidth(iv.bounds) + 40) break;
        if (ReoHasNextUp(p, 3)) break;
        [chain addObject:p];
    }
    for (UIView *s in iv.superview.subviews) {
        if (s != iv && ![s isKindOfClass:[UILabel class]] && !ReoHasNextUp(s, 3) &&
            ReoClose(s.frame, iv.frame)) {
            [chain addObject:s];
        }
    }

    // C) Phần nhìn: bỏ nền thừa / vừa khít (ảnh không vuông) hoặc trả lại như Reo (ảnh vuông)
    if (apply) {
        if (!objc_getAssociatedObject(iv, kReoModeKey)) {
            objc_setAssociatedObject(iv, kReoModeKey, @(iv.contentMode),
                                     OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        for (UIView *v in chain) ReoMarkClear(v);
        iv.contentMode = UIViewContentModeScaleAspectFit;
    } else {
        for (UIView *v in chain) ReoUnmark(v);
        NSNumber *m = objc_getAssociatedObject(iv, kReoModeKey);
        if (m) {
            iv.contentMode = (UIViewContentMode)m.integerValue;
            objc_setAssociatedObject(iv, kReoModeKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
    }

    // D) Khung ảnh (chỉ chế độ lớn): phóng ảnh ngang theo Cài đặt, rồi nhường chỗ đồng hồ
    CGRect target = orig;
    CGSize is = iv.image.size;
    if (maximized && is.width > 0 && is.height > 0 && orig.size.width >= 200) {
        if (apply) {
            CGFloat W = MIN(ReoPrefNumber(CFSTR("artworkWidth"), 350),
                            [UIScreen mainScreen].bounds.size.width);
            CGFloat H = W * is.height / is.width;
            target = CGRectMake(CGRectGetMidX(orig) - W / 2, CGRectGetMidY(orig) - H / 2, W, H);
        }
        target = ReoClampArtwork(iv, target);
    }
    if (!CGRectEqualToRect(target, orig)) {
        objc_setAssociatedObject(iv, kReoArtOrigKey, [NSValue valueWithCGRect:orig],
                                 OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        iv.frame = target;
        objc_setAssociatedObject(iv, kReoArtAppliedKey, [NSValue valueWithCGRect:iv.frame],
                                 OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }

    // E) Bo góc theo vùng ảnh thật (ảnh không vuông) hoặc bỏ mask (ảnh vuông)
    if (apply) ReoRoundImageRect(iv);
    else iv.layer.mask = nil;
}

// --- NextUp 3: manager dùng chung ---------------------------------------------------------------
// Hàng Next Up (NUNextUpRowView.hasContent) chính là NUNextUpManager.isActive, và chỉ true khi:
//   NextUp bật + bài đang phát thuộc đúng 1 trong 6 app NextUp hỗ trợ (Music, Podcasts, YouTube Music,
//   YouTube, Spotify, SoundCloud) + provider của app đó đã trả dữ liệu. Manager chỉ bắt đầu theo dõi
//   app đang phát khi có ai gọi -start; NextUp tự gọi ở viewWillAppear của màn điều khiển gốc, còn khi
//   dùng Reo thì ReoFix gọi thêm một lần khi tạo hàng (không gọi lặp: tránh vòng truy vấn tốn pin).
static CFTimeInterval gNuStartLast = 0;

static NSObject *ReoNextUpManager(void) {
    Class mc = objc_getClass("NUNextUpManager");
    SEL ss = NSSelectorFromString(@"sharedManager");
    if (!mc || ![mc respondsToSelector:ss]) return nil;
    return ((id (*)(id, SEL))objc_msgSend)(mc, ss);
}

static void ReoNextUpStart(CFTimeInterval minGap) {
    CFTimeInterval now = CACurrentMediaTime();
    if (gNuStartLast > 0 && now - gNuStartLast < minGap) return;
    NSObject *m = ReoNextUpManager();
    SEL st = NSSelectorFromString(@"start");
    if (!m || ![m respondsToSelector:st]) return;
    gNuStartLast = now;
    ((void (*)(id, SEL))objc_msgSend)(m, st);
}

// Gọi getter BOOL/NSInteger/id bằng tên selector; -1 nếu không có
static int ReoCallBool(NSObject *o, NSString *name) {
    SEL s = NSSelectorFromString(name);
    if (!o || ![o respondsToSelector:s]) return -1;
    return ((BOOL (*)(id, SEL))objc_msgSend)(o, s) ? 1 : 0;
}
static long ReoCallLong(NSObject *o, NSString *name) {
    SEL s = NSSelectorFromString(name);
    if (!o || ![o respondsToSelector:s]) return -1;
    return ((long (*)(id, SEL))objc_msgSend)(o, s);
}
static NSString *ReoCallString(NSObject *o, NSString *name) {
    SEL s = NSSelectorFromString(name);
    if (!o || ![o respondsToSelector:s]) return nil;
    id r = ((id (*)(id, SEL))objc_msgSend)(o, s);
    return [r isKindOfClass:[NSString class]] ? r : nil;
}

static NSString *ReoR(CGRect r);

// Một dòng cho bảng chẩn đoán: hàng Next Up + manager đang ở trạng thái nào
static NSString *ReoNextUpHud(UIView *container) {
    Class rc = objc_getClass("NUNextUpRowView");
    if (!rc) return @"nu: KHONG co class NUNextUpRowView (NextUp 3 chua nap vao SpringBoard?)";
    UIView *row = objc_getAssociatedObject(container, kReoNextUpKey);
    NSObject *m = ReoNextUpManager();
    NSString *t = ReoCallString(m, @"nextTitle");
    if (t.length > 14) t = [t substringToIndex:14];
    CGRect rf = (row && row.superview) ? ReoScreenFrame(row) : CGRectZero;
    return [NSString stringWithFormat:@"nu row%d hid%d has%d %@ | mgr%d act%d prov%d src%ld trk%d | \"%@\"",
            row != nil, row ? row.hidden : -1, row ? ReoCallBool(row, @"hasContent") : -1, ReoR(rf),
            m != nil, ReoCallBool(m, @"isActive"), ReoCallBool(m, @"providerActive"),
            ReoCallLong(m, @"source"), ReoCallBool(m, @"nowPlayingTrackingActive"), t ?: @""];
}

// Gắn hàng "Up Next" của NextUp 3 (class NUNextUpRowView) vào player của Reo.
// Ưu tiên đặt ngay DƯới khung thông tin (nếu còn chỗ trước đèn pin/camera), không đủ chỗ thì
// đặt phía trên. Hiện ở cả chế độ lớn lẫn thu nhỏ, ẩn khi player đã trượt xuống (dismissed).
static void ReoUpdateNextUp(UIView *container, BOOL show, BOOL isMax) {
    UIView *row = objc_getAssociatedObject(container, kReoNextUpKey);
    Class rowClass = objc_getClass("NUNextUpRowView");
    UIView *bg = ReoIvar(container, "_reoMiniBackgroundView");
    CGRect sb = [UIScreen mainScreen].bounds;
    BOOL panelOk = NO, dismissed = NO;
    CGRect bfs = CGRectZero;
    if ([bg isKindOfClass:[UIView class]] && bg.superview) {
        bfs = ReoScreenFrame(bg);   // khung thông tin theo toạ độ màn hình
        panelOk = bfs.size.width >= sb.size.width * 0.6 && bfs.size.height >= 130;
        dismissed = bfs.origin.y > sb.size.height * 0.85;
    }
    if (container.hidden || container.alpha < 0.01) dismissed = YES;   // player đã bị ẩn
    if (!rowClass || !show || !panelOk || dismissed) {
        if (row) row.hidden = YES;
        return;
    }
    if (!row) {
        row = [[rowClass alloc] initWithFrame:CGRectMake(0, 0, 320, 64)];
        objc_setAssociatedObject(container, kReoNextUpKey, row, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        ReoNextUpStart(0);   // vừa tạo hàng: cho manager bắt đầu theo dõi app đang phát ngay
    }
    if (row.superview != bg.superview) [bg.superview addSubview:row];

    SEL refreshSel = NSSelectorFromString(@"refreshFromManager");
    if ([row respondsToSelector:refreshSel]) {
        ((void (*)(id, SEL))objc_msgSend)(row, refreshSel);
    }
    BOOL has = YES;
    SEL hasSel = NSSelectorFromString(@"hasContent");
    if ([row respondsToSelector:hasSel]) {
        has = ((BOOL (*)(id, SEL))objc_msgSend)(row, hasSel);
    }
    CGFloat h = 64;
    SEL hSel = NSSelectorFromString(@"preferredHeight");
    if ([rowClass respondsToSelector:hSel]) {
        h = ((CGFloat (*)(id, SEL))objc_msgSend)(rowClass, hSel);
    }

    CGRect pf = bg.frame;
    CGFloat gap = 6;
    // Còn chỗ dưới khung (phía trên đèn pin/camera, ~108pt tính từ đáy màn hình) thì đặt dưới
    BOOL fitsBelow = CGRectGetMaxY(bfs) + gap + h <= sb.size.height - 108;
    CGFloat y;
    if (ReoPrefBool(CFSTR("nextUpBelow"), YES) && fitsBelow) {
        y = CGRectGetMaxY(pf) + gap;
    } else if (isMax) {
        // Chế độ lớn: hàng nằm trong khoảng trống giữa ảnh bìa và khung thông tin. Hàng cao h pt nhưng nội dung
        // chỉ chiếm ~15..59 (đường kẻ ở đỉnh, đệm trống ~14 pt ở đáy). Đặt sát khung thông tin (nội dung cách
        // khung ~8 pt) và luôn cách đáy ảnh bìa >= 4 pt để đường kẻ không dính vào ảnh.
        y = pf.origin.y - h + 6;
        UIView *artv = ReoIvar(container, "_artworkImageView");
        if ([artv isKindOfClass:[UIView class]] && artv.superview == bg.superview && !artv.hidden &&
            CGRectGetMaxY(artv.frame) <= pf.origin.y + 20) {
            y = MAX(y, CGRectGetMaxY(artv.frame) + 4);
        }
    } else {
        // Chế độ thu nhỏ có nút mũi tên ẩn ngay phía trên khung -> chừa thêm chỗ
        y = pf.origin.y - h - 8 - 52;
    }
    row.frame = CGRectMake(pf.origin.x, y, pf.size.width, h);
    row.hidden = !has;
    [row.superview bringSubviewToFront:row];
}

// Chỉ coi là "chế độ lớn" khi: player còn hiện, khung thông tin rộng gần hết màn hình, chưa trượt xuống
// dưới đáy (dismissed), và ảnh bìa nằm phía trên khung. Các chế độ khác (thu nhỏ, ẩn)
// ReoFix không đụng vào để Reo tự xử lý như bình thường.
static BOOL ReoIsMaximized(UIView *container) {
    if (container.hidden || container.alpha < 0.01) return NO;
    UIView *bg = ReoIvar(container, "_reoMiniBackgroundView");
    if (![bg isKindOfClass:[UIView class]] || !bg.superview) return NO;
    CGRect sb = [UIScreen mainScreen].bounds;
    CGRect bf = ReoScreenFrame(bg);
    if (bf.size.width < sb.size.width * 0.6 || bf.size.height < 130) return NO;
    if (bf.origin.y > sb.size.height * 0.85) return NO;          // đã trượt xuống đáy
    // Không xác minh được ảnh bìa thì KHÔNG coi là chế độ lớn (trước đây trả YES: ở chế độ thu nhỏ khung
    // bị kéo rộng và không dịch lên được nếu không đọc được ảnh bìa).
    UIImageView *art = ReoIvar(container, "_artworkImageView");
    if (![art isKindOfClass:[UIImageView class]] || !art.superview) return NO;
    CGRect af = ReoScreenFrame(art);
    if (CGRectGetMaxY(af) > bf.origin.y + 20) return NO;          // ảnh phải nằm trên khung
    return YES;
}

// Gom khung của các thẻ thông báo THẬT (NCNotificationShortLookView) đang nhìn thấy.
// Từ số đo thật 0.1.4: không được tính theo NCNotificationListCell, vì danh sách còn chứa
//  * một cell rỗng cao 240 pt (nền PLPlatterView bị ẩn) nằm ở y 336/400/528 -> đỉnh thông báo bị tính sai,
//  * cell vừa vuốt xoá đang trượt ra ngoài màn hình (x = -1172) -> trạng thái "đang mở" bị kẹt.
static void ReoCollectCells(UIView *v, CGRect *u, int depth) {
    if (depth < 0) return;
    CGSize ss = [UIScreen mainScreen].bounds.size;
    CGFloat sw = ss.width;
    for (UIView *sv in v.subviews) {
        if (sv.hidden || sv.alpha < 0.05) continue;
        const char *n = class_getName(object_getClass(sv));
        if (n && strstr(n, "NCNotificationShortLookView")) {
            CGRect r = ReoScreenRect(sv.superview, sv.frame);
            CGFloat cx = CGRectGetMidX(r);
            // Thẻ đã cuộn hẳn ra khỏi màn hình (danh sách dài) không tính
            if (r.size.height >= 40 && r.size.width >= 200 && cx > 0 && cx < sw &&
                CGRectGetMaxY(r) > 60 && r.origin.y < ss.height) *u = CGRectUnion(*u, r);
            continue;
        }
        ReoCollectCells(sv, u, depth - 1);
    }
}

// Đỉnh (toạ độ màn hình) của thông báo nhìn thấy cao nhất; 0 nếu không có thông báo nào đang hiện
static CGFloat ReoNotificationTop(void) {
    UIView *l = ReoNotifRoot();             // danh sách gốc
    if (!l || !ReoChainVisible(l)) return 0;
    CGRect u = CGRectNull;
    ReoCollectCells(l, &u, 14);
    if (CGRectIsNull(u) || u.size.height < 40) return 0;
    CGFloat sh = [UIScreen mainScreen].bounds.size.height;
    if (u.origin.y > sh - 100) return 0;
    // Danh sách mở rộng / cuộn: thẻ đầu có thể nằm sát hoặc lên trên đỉnh màn hình -> coi như đỉnh ở y=60
    // (vẫn là "có thông báo" và chắc chắn không còn chỗ cho player phía trên)
    return MAX(u.origin.y, 60);
}

// Dịch NHÌN THẤY các view con của container Reo lên dy bằng layer.sublayerTransform.
// Không sửa frame/transform của view nào: Reo tự đặt frame và dùng transform của container (hiệu ứng thu nhỏ,
// hạ xuống đáy), nên bản 0.1.4 trở về trước sửa frame từng view bị Reo ghi đè -> ảnh bìa và khung lệch nhau.
// sublayerTransform là thuộc tính Reo không dùng. Số đo hình học (frame) vì thế luôn là vị trí gốc của Reo.
// Vùng chạm dịch theo ở hook hitTest bên dưới.
static void ReoApplyLift(UIView *container, CGFloat dy) {   // dy > 0: lên, dy < 0: xuống (ẩn dưới đáy)
    CATransform3D to = (fabs(dy) < 0.5) ? CATransform3DIdentity : CATransform3DMakeTranslation(0, -dy, 0);
    CALayer *layer = container.layer;
    if (CATransform3DEqualToTransform(layer.sublayerTransform, to)) return;
    CATransform3D from = layer.sublayerTransform;
    CALayer *pl = [layer presentationLayer];
    if (pl) from = pl.sublayerTransform;
    layer.sublayerTransform = to;
    // Đổi nhỏ (Reo đang chạy hiệu ứng, ReoFix bám theo từng khung): đặt thẳng.
    // Đổi lớn (ẩn xuống đáy / trồi lên / mở-đóng thông báo): trượt mượt.
    if (fabs(to.m42 - from.m42) < 24) {
        [layer removeAnimationForKey:@"reofixLift"];
        return;
    }
    CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"sublayerTransform"];
    a.fromValue = [NSValue valueWithCATransform3D:from];
    a.toValue = [NSValue valueWithCATransform3D:to];
    a.duration = 0.3;
    a.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    [layer addAnimation:a forKey:@"reofixLift"];
}

// Độ dịch lên (pt) để khung player (+ hàng Next Up) nằm gọn phía trên thông báo, cách liftGap.
// Số đo (frame) luôn là vị trí gốc của Reo vì lift chỉ là sublayerTransform.
// Thứ tự từ trên xuống: [đồng hồ] [hàng Axon] [nút mũi tên] [khung player] [Next Up] [thông báo]
static CGFloat ReoComputeLift(UIView *container, CGFloat nTop) {
    UIView *bg = ReoIvar(container, "_reoMiniBackgroundView");
    if (nTop <= 0 || ![bg isKindOfClass:[UIView class]] || !bg.superview) return 0;
    CGRect sb = [UIScreen mainScreen].bounds;
    CGRect bfs = ReoScreenFrame(bg);
    gDbgBfs = bfs;
    // Player đang bị Reo hạ xuống đáy màn hình (dismissed, chỉ còn hé ra ~20 pt): để yên, đừng nâng lên giữa màn hình
    if (bfs.origin.y > sb.size.height * 0.85) { gDbgWant = 0; gDbgMaxLift = 0; gDbgNTop = nTop; return 0; }
    UIView *row = objc_getAssociatedObject(container, kReoNextUpKey);
    BOOL rowBelow = ReoPrefBool(CFSTR("nextUpBelow"), YES);   // hàng Next Up chỉ chiếm chỗ phía dưới khi đặt dưới khung
    CGFloat rowExtra = (rowBelow && row && !row.hidden) ? row.frame.size.height + 6 : 0;
    CGFloat gap = ReoPrefNumber(CFSTR("liftGap"), 8);
    CGFloat want = (CGRectGetMaxY(bfs) + rowExtra) - (nTop - gap);
    // Đỉnh khung player thấp nhất được phép: dưới đồng hồ (cộng chỗ nút mũi tên ~52 pt nằm trên khung),
    // và dưới hàng icon Axon (nút mũi tên ở góc phải chỉ vướng icon khi hàng icon kéo dài tới góc phải)
    CGFloat minTop = ReoClockBottom() + 8 + 52;
    CGRect ax = ReoAxonIconsRect();
    if (!CGRectIsNull(ax)) {
        BOOL reachesArrow = CGRectGetMaxX(ax) > sb.size.width - 80;
        minTop = MAX(minTop, CGRectGetMaxY(ax) + 8 + (reachesArrow ? 52 : 0));
    }
    CGFloat maxLift = bfs.origin.y - minTop;
    gDbgWant = want; gDbgMaxLift = maxLift; gDbgRowExtra = rowExtra; gDbgNTop = nTop;   // cho nhật ký
    gDbgHide = NO;
    // Thông báo quá nhiều / quá dài (danh sách mở rộng): không còn chỗ cho player (+ hàng Next Up) phía trên
    // thông báo mà không đè lên -> hạ cả player xuống dưới đáy màn hình. Thông báo thu gọn / đóng lại thì
    // want <= maxLift trở lại và player tự trồi lên (tính lại ở mỗi lượt).
    if (want > maxLift + 4 && ReoPrefBool(CFSTR("hideWhenFull"), YES)) {
        gDbgHide = YES;
        return -(sb.size.height - (bfs.origin.y - 60));   // đỉnh view cao nhất (nút mũi tên) cũng xuống dưới đáy
    }
    if (want < 0.5) return 0;
    return MAX(0, MIN(want, maxLift));
}

// Reo còn đang chạy hiệu ứng khi mình tính vị trí -> tính lại 2 lần sau khi nó đứng yên
static void ReoScheduleRecheck(UIView *container) {
    if (!container || gInRecheck || objc_getAssociatedObject(container, kReoRecheckKey)) return;
    objc_setAssociatedObject(container, kReoRecheckKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    __weak UIView *weakC = container;
    double delays[2] = {0.8, 2.0};
    for (int i = 0; i < 2; i++) {
        BOOL last = (i == 1);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delays[i] * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            UIView *c = weakC;
            if (!c) return;
            if (last) objc_setAssociatedObject(c, kReoRecheckKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            gInRecheck = YES;
            ReoFixContainer(c);
            gInRecheck = NO;
        });
    }
}

// Nút bấm ảnh (nhấn góc ảnh để thu nhỏ) phải trùng với ảnh đã đổi cỡ
static void ReoSyncArtButton(UIView *container, UIImageView *art) {
    UIView *btn = ReoIvar(container, "_reoArtworkButton");
    if (![btn isKindOfClass:[UIView class]] || ![art isKindOfClass:[UIImageView class]]) return;
    NSValue *ap = objc_getAssociatedObject(btn, kReoBtnAppliedKey);
    NSValue *og = objc_getAssociatedObject(btn, kReoBtnOrigKey);
    if (ap && og && CGRectEqualToRect(btn.frame, [ap CGRectValue])) btn.frame = [og CGRectValue];
    objc_setAssociatedObject(btn, kReoBtnAppliedKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(btn, kReoBtnOrigKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (objc_getAssociatedObject(art, kReoArtAppliedKey)) {
        objc_setAssociatedObject(btn, kReoBtnOrigKey, [NSValue valueWithCGRect:btn.frame], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        btn.frame = art.frame;
        objc_setAssociatedObject(btn, kReoBtnAppliedKey, [NSValue valueWithCGRect:btn.frame], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

// ---------------------------------------------------------------------------------------------
// Thu nhỏ / phóng lớn player: làm ĐÚNG như ngón tay bấm vào ảnh bìa. Reo gắn nút ảnh bìa với hàm
// hideReoView (đổi lớn <-> nhỏ). TUYỆT ĐỐI không gọi minimizeMiniPlayer: hàm đó là "vuốt xuống",
// khi player đã nhỏ nó làm player bị ẩn (_dismissed).
// ---------------------------------------------------------------------------------------------
static BOOL ReoTapArtwork(UIView *container) {
    UIView *btn = ReoIvar(container, "_reoArtworkButton");
    if (![btn isKindOfClass:[UIControl class]]) return NO;
    [(UIControl *)btn sendActionsForControlEvents:UIControlEventTouchUpInside];
    return YES;
}

static BOOL ReoLandscapeNow(void) {
    CGRect sb = [UIScreen mainScreen].bounds;
    return sb.size.width > sb.size.height;
}

// Thu nhỏ khi thông báo vừa mở: chỉ khi Reo đang ở chế độ lớn thật sự.
// Chạy theo mức (không chỉ một lần): trong 4 s đầu sau khi thông báo mở, hễ player còn ở chế độ lớn,
// Reo không bận hiệu ứng và đã cách lần bấm trước >= 0.9 s thì bấm lại (tối đa 3 lần).
// Hết 4 s thì tôn trọng thao tác tay của bạn.
static void ReoAutoMinimizeTry(void) {
    gAutoBusy = NO;
    UIView *c = gReoContainer;
    if (!c || !gNotifOpen || ReoLandscapeNow()) return;
    CFTimeInterval now = CACurrentMediaTime();
    if (now > gAutoDeadline || gAutoTaps >= 3 || now - gLastTap < 0.9) return;
    ReoState s = ReoReadState();
    if (s.known && (s.hiding || s.minimized || s.dismissed)) return;
    if (!s.known && gAutoTaps >= 1) return;               // không đọc được trạng thái Reo: chỉ bấm 1 lần cho khỏi đảo ngược
    if (!ReoIsMaximized(c)) return;                       // đã nhỏ / đã ẩn: không đụng
    if (ReoTapArtwork(c)) {
        gMinimizedByUs = YES;
        gAutoTaps++;
        gLastTap = now;
        ReoLog(@"AUTO tap #%d reo known=%d min=%d dis=%d hid=%d", gAutoTaps, s.known, s.minimized, s.dismissed, s.hiding);
        ReoFollow(c, 1.5);
    }
}

// Canh định kỳ (3 lần/giây) khi thông báo đang mở: bắt các thay đổi muộn của Reo/Axon (hiệu ứng dài,
// Reo đổi vị trí sau khi mình tính) mà không cần chạy từng khung hình. Tự nghỉ sau 15 s đứng yên.
static void ReoWatchTick(void) {
    if (!(gNotifOpen || gAxonTouched || gMinimizedByUs) || CACurrentMediaTime() - gLastChange > 15.0) {
        gWatching = NO;
        return;
    }
    UIView *c = gReoContainer;
    if (c && !gTicker) {
        double before = gSig;
        gInRecheck = YES;
        ReoFixContainer(c);
        gInRecheck = NO;
        if (fabs(gSig - before) > 0.01) ReoFollow(c, 0.8);
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ ReoWatchTick(); });
}
static void ReoWatchStart(void) {
    gLastChange = CACurrentMediaTime();
    if (gWatching) return;
    gWatching = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ ReoWatchTick(); });
}

// Phóng lớn lại khi thông báo đóng — chỉ khi chính ReoFix đã thu nhỏ và Reo xác nhận đang ở dạng nhỏ
static void ReoRestoreTry(int retries) {
    UIView *c = gReoContainer;
    if (!c || gNotifOpen || !gMinimizedByUs) return;
    if (ReoLandscapeNow()) { gMinimizedByUs = NO; return; }
    ReoState s = ReoReadState();
    if (s.known && s.hiding && retries > 0) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ ReoRestoreTry(retries - 1); });
        return;
    }
    gMinimizedByUs = NO;
    if (c.hidden || c.alpha < 0.01) return;               // người dùng đã ẩn player: để yên
    BOOL canTap;
    if (s.known) canTap = s.minimized && !s.dismissed && !s.hiding;
    else canTap = !ReoIsMaximized(c);
    ReoLog(@"RESTORE canTap=%d reo known=%d min=%d dis=%d hid=%d", canTap, s.known, s.minimized, s.dismissed, s.hiding);
    if (canTap && ReoTapArtwork(c)) ReoFollow(c, 1.5);
}

static void ReoScheduleRestore(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ ReoRestoreTry(3); });
}

// Máy trạng thái "thông báo đang mở": mở = đã chạm icon Axon VÀ có cell thông báo nhìn thấy.
// Đóng = hết cell (chờ 0.8 s sau lần chạm cuối để khỏi nhầm lúc Axon đổi sang icon khác).
static void ReoUpdateNotifState(BOOL canLift, BOOL hiddenNow, CGFloat nTop) {
    CFTimeInterval now = CACurrentMediaTime();
    BOOL cells = canLift && nTop > 0 && ReoAxonView() != nil;
    if (!gNotifOpen) {
        if (gAxonTouched && cells && !hiddenNow) {
            gNotifOpen = YES;
            gAutoDeadline = now + 4.0;     // việc tự thu nhỏ do ReoFixContainer kích hoạt theo mức, trong 4 s này
            gAutoTaps = 0;
            gLastTap = 0;
            ReoState s = ReoReadState();
            ReoLog(@"OPEN nTop=%.1f reo known=%d min=%d dis=%d hid=%d", nTop, s.known, s.minimized, s.dismissed, s.hiding);
        } else if (gAxonTouched && now - gAxonEventTime > 3.0) {
            gAxonTouched = NO;
        }
    } else if (!cells && now - gAxonEventTime > 0.8) {
        gNotifOpen = NO;
        gAxonTouched = NO;
        ReoLog(@"CLOSE minimizedByUs=%d", gMinimizedByUs);
        ReoScheduleRestore();
    }
}

// ---------------------------------------------------------------------------------------------
// Bảng chẩn đoán (HUD) trên màn hình khóa: vài dòng chữ nhỏ ngay dưới thanh trạng thái, đọc số LIVE từ
// view thật (không phải số của lượt tính cuối). Chỉ để bạn chụp màn hình gửi lại — tắt trong Cài đặt.
// ---------------------------------------------------------------------------------------------
static UILabel *gHud;
static BOOL gHudRunning = NO;
static NSString *gLastStateStr;

static NSString *ReoR(CGRect r) {
    if (CGRectIsNull(r) || CGRectIsInfinite(r)) return @"-";
    return [NSString stringWithFormat:@"%.0f,%.0f %.0fx%.0f", r.origin.x, r.origin.y, r.size.width, r.size.height];
}

// Số icon Axon đang nhìn thấy (bỏ cell ẩn trong hàng đợi tái sử dụng); -1 nếu không thấy hàng Axon
static int ReoCountAxonCells(void) {
    UIView *av = ReoAxonView();
    if (!av) return -1;
    int n = 0;
    for (UIView *cv in av.subviews) {
        for (UIView *cell in cv.subviews) {
            if (cell.hidden || cell.alpha < 0.05) continue;
            const char *nm = class_getName(object_getClass(cell));
            if (nm && strstr(nm, "AXNAppCell")) n++;
        }
    }
    return n;
}

static NSString *ReoHudText(UIView *c) {
    ReoState rs = ReoReadState();
    UIView *bg = ReoIvar(c, "_reoMiniBackgroundView");
    UIImageView *art = ReoIvar(c, "_artworkImageView");
    BOOL artIV = [art isKindOfClass:[UIImageView class]];
    CGRect bf = ([bg isKindOfClass:[UIView class]] && bg.superview) ? ReoScreenFrame(bg) : CGRectZero;
    CGRect af = (artIV && art.superview) ? ReoScreenFrame(art) : CGRectZero;
    NSValue *lap = artIV ? objc_getAssociatedObject(art, kReoLiftAppliedKey) : nil;
    NSValue *aap = artIV ? objc_getAssociatedObject(art, kReoArtAppliedKey) : nil;
    NSValue *ours = lap ?: aap;
    BOOL over = ours && !CGRectEqualToRect(art.frame, [ours CGRectValue]);
    BOOL hiddenNow = c.hidden || c.alpha < 0.01;
    UIView *root = ReoNotifRoot();
    UIView *av = ReoAxonView();
    CGSize isz = artIV ? art.image.size : CGSizeZero;
    NSMutableString *s = [NSMutableString string];
    [s appendFormat:@"ReoFix 0.1.7 t%.0f P%u ow%u | en%d au%d aA%d aC%d nu%d | clk%.0f gap%.0f aw%.0f\n",
        fmod(CACurrentMediaTime(), 1000.0), gPassCount, gGuardHits,
        ReoPrefBool(CFSTR("enabled"), YES), ReoPrefBool(CFSTR("autoMinimize"), YES),
        ReoPrefBool(CFSTR("avoidAxon"), YES), ReoPrefBool(CFSTR("avoidClock"), YES),
        ReoPrefBool(CFSTR("showNextUp"), YES), ReoClockBottom(),
        ReoPrefNumber(CFSTR("liftGap"), 8), ReoPrefNumber(CFSTR("artworkWidth"), 350)];
    [s appendFormat:@"max%d hid%d | reo k%d min%d dis%d hid%d | art IV%d img%.0fx%.0f ours%d over%d\n",
        ReoIsMaximized(c), hiddenNow, rs.known, rs.minimized, rs.dismissed, rs.hiding,
        artIV, isz.width, isz.height, ours != nil, over];
    CGFloat liftNow = [objc_getAssociatedObject(c, kReoLiftValueKey) doubleValue];
    [s appendFormat:@"bg goc %@ hien y%.0f | art goc %@\n", ReoR(bf), bf.origin.y - liftNow, ReoR(af)];
    [s appendFormat:@"axon root%d view%d vis%d cells%d icons %@\n", root != nil, av != nil,
        av ? ReoChainVisible(av) : 0, ReoCountAxonCells(), ReoR(ReoAxonIconsRect())];
    [s appendFormat:@"notif top%.0f open%d touch%d byUs%d | lift %.1f want %.1f max %.1f nTop %.0f\n",
        ReoNotificationTop(), gNotifOpen, gAxonTouched, gMinimizedByUs,
        [objc_getAssociatedObject(c, kReoLiftValueKey) doubleValue], gDbgWant, gDbgMaxLift, gDbgNTop];
    [s appendString:ReoNextUpHud(c)];
    return s;
}

static void ReoHudUpdate(UIView *c) {
    UIView *parent = c.superview;
    if (!parent) { gHud.hidden = YES; return; }
    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    if (!gHud) {
        gHud = [[UILabel alloc] initWithFrame:CGRectMake(6, 48, sw - 12, 60)];
        gHud.numberOfLines = 0;
        gHud.font = [UIFont monospacedSystemFontOfSize:8 weight:UIFontWeightRegular];
        gHud.textColor = [UIColor colorWithRed:1.0 green:0.95 blue:0.4 alpha:1.0];
        gHud.backgroundColor = [UIColor colorWithWhite:0 alpha:0.62];
        gHud.userInteractionEnabled = NO;
        gHud.layer.cornerRadius = 4;
        gHud.clipsToBounds = YES;
    }
    if (gHud.superview != parent) [parent addSubview:gHud];
    else if (parent.subviews.lastObject != gHud) [parent bringSubviewToFront:gHud];
    gHud.hidden = NO;
    gHud.text = ReoHudText(c);
    CGSize fit = [gHud sizeThatFits:CGSizeMake(sw - 12, 400)];
    gHud.frame = CGRectMake(6, 48, sw - 12, fit.height);
}

static void ReoHudTick(void) {
    UIView *c = gReoContainer;
    if (!c || !c.superview || !ReoPrefBool(CFSTR("hud"), YES) || !ReoChainVisible(c.superview)) {
        gHudRunning = NO;
        gHud.hidden = YES;
        return;
    }
    ReoHudUpdate(c);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ ReoHudTick(); });
}

// Mỗi lượt tính gọi một lần: bật vòng cập nhật HUD (2 lần/giây) nếu chưa chạy
static void ReoHudKick(void) {
    if (gHudRunning || !ReoPrefBool(CFSTR("hud"), YES)) return;
    gHudRunning = YES;
    dispatch_async(dispatch_get_main_queue(), ^{ ReoHudTick(); });
}

static void ReoFixContainerBody(UIView *container) {
    if (!container.superview) return;
    gReoContainer = container;
    NSMutableArray *views = [NSMutableArray array];
    UIImageView *art = ReoIvar(container, "_artworkImageView");
    if ([art isKindOfClass:[UIImageView class]] && art.image) {
        [views addObject:art];
    } else {
        ReoCollectImageViews(container, views);
    }

    BOOL landscape = ReoLandscapeNow();                      // màn hình xoay ngang: không can thiệp
    BOOL enabled = ReoPrefBool(CFSTR("enabled"), YES) && !landscape;
    BOOL hiddenNow = container.hidden || container.alpha < 0.01;   // player đang bị ẩn (dismissed)
    BOOL maximized = !landscape && !hiddenNow && ReoIsMaximized(container);
    BOOL active = enabled && maximized;   // phóng ảnh, kéo rộng khung, Next Up: chỉ ở chế độ lớn
    for (UIImageView *iv in views) {
        if (!objc_getAssociatedObject(iv, kReoBoxKey)) {
            ReoWeakBox *box = [ReoWeakBox new];
            box.v = container;
            objc_setAssociatedObject(iv, kReoBoxKey, box, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        CGSize is = iv.image.size;
        if (is.height <= 0) continue;
        BOOL nonSquare = fabs(is.width / is.height - 1.0) > 0.05;
        ReoProcessImage(container, iv, nonSquare && enabled, maximized);   // phần nhìn: mọi chế độ
    }
    if ([art isKindOfClass:[UIImageView class]]) ReoSyncArtButton(container, art);
    ReoReshapePanel(container, active);   // khung thông tin: áp dụng cho mọi bài (chế độ lớn)

    // Mở thông báo (chạm icon Axon): player Ở DẠNG THU NHỎ dịch lên để nhường chỗ cho thông báo
    BOOL canLift = enabled && ReoPrefBool(CFSTR("autoMinimize"), YES);
    CGFloat nTop = canLift ? ReoNotificationTop() : 0;
    ReoUpdateNotifState(canLift, hiddenNow, nTop);
    CGFloat lift = 0;
    if (canLift && gNotifOpen && !maximized && !hiddenNow) lift = ReoComputeLift(container, nTop);
    objc_setAssociatedObject(container, kReoLiftValueKey, @(lift), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    ReoApplyLift(container, lift);
    ReoUpdateNextUp(container, enabled && ReoPrefBool(CFSTR("showNextUp"), YES), maximized);

    // Chữ ký hình học: đổi = còn chuyển động -> ticker/watch tiếp tục bám cho tới khi đứng yên
    UIView *bgNow = ReoIvar(container, "_reoMiniBackgroundView");
    CGRect bfsNow = ([bgNow isKindOfClass:[UIView class]] && bgNow.superview) ? ReoScreenFrame(bgNow) : CGRectZero;
    double sig = lift * 7.0 + nTop * 13.0 + bfsNow.origin.y * 3.0 + CGRectGetMaxY(bfsNow) * 5.0 +
                 (maximized ? 1000.0 : 0.0) + (hiddenNow ? 2000.0 : 0.0) + (gNotifOpen ? 4000.0 : 0.0);
    BOOL moved = fabs(sig - gSig) > 0.01;
    gSig = sig;
    CFTimeInterval now = CACurrentMediaTime();
    if (moved) gLastChange = now;
    if (moved && (gNotifOpen || gAxonTouched || gMinimizedByUs)) ReoWatchStart();

    // Nhật ký trạng thái rời rạc: chỉ ghi khi đổi (max / ẩn / thấy Axon / số icon / mở thông báo / ảnh bìa)
    {
        BOOL artIV = [art isKindOfClass:[UIImageView class]];
        NSString *st = [NSString stringWithFormat:@"max=%d hid=%d en=%d axonView=%d cells=%d open=%d artIV=%d img=%d",
                        maximized, hiddenNow, enabled, ReoAxonView() != nil, ReoCountAxonCells(), gNotifOpen,
                        artIV, artIV && ((UIImageView *)art).image != nil];
        if (![st isEqualToString:gLastStateStr]) {
            gLastStateStr = st;
            ReoLog(@"STATE %@ bf=%@ nTop=%.0f lift=%.1f", st, ReoR(bfsNow), nTop, lift);
        }
    }

    // Nhật ký: mỗi lần độ dịch lên đổi >= 1.5 pt (tối đa ~7 dòng/giây) kèm toàn bộ số liệu đầu vào
    if (gNotifOpen && fabs(lift - gLastLiftLogged) >= 1.5 && now - gLastLiftLog > 0.15) {
        gLastLiftLog = now;
        gLastLiftLogged = lift;
        ReoState rs = ReoReadState();
        ReoLog(@"%@ %.1f want=%.1f max=%.1f nTop=%.1f rowExtra=%.0f bfs=%@ max=%d hid=%d reo(min=%d dis=%d hid=%d)",
               gDbgHide ? @"HIDE" : @"LIFT", lift, gDbgWant, gDbgMaxLift, gDbgNTop, gDbgRowExtra, NSStringFromCGRect(gDbgBfs),
               maximized, hiddenNow, rs.minimized, rs.dismissed, rs.hiding);
    } else if (!gNotifOpen) {
        gLastLiftLogged = -1;
    }

    // Tự thu nhỏ khi thông báo mở mà player còn lớn (làm ngoài lượt layout hiện tại)
    if (canLift && gNotifOpen && maximized && !gAutoBusy && now <= gAutoDeadline && gAutoTaps < 3) {
        gAutoBusy = YES;
        dispatch_async(dispatch_get_main_queue(), ^{ ReoAutoMinimizeTry(); });
    }

    ReoScheduleRecheck(container);
}

static void ReoNextUpObserve(void);   // khai báo trước

// Mọi lượt tính đều đi qua đây: đánh dấu "đang tính" để hook setFrame: bỏ qua các lần đặt frame của chính mình
static void ReoFixContainer(UIView *container) {
    if (!container.superview) return;
    ReoNextUpObserve();
    gPassDepth++;
    gPassCount++;
    gReoContainerPtr = (__bridge void *)container;
    ReoFixContainerBody(container);
    gPassDepth--;
    ReoHudKick();
}

// --- NextUp báo "dữ liệu đổi" -> chạy lại một lượt ngay --------------------------------------------
// Trước 0.1.3: hàng Next Up chỉ được hiện/ẩn lại trong lượt tính của ReoFix, mà lượt tính chỉ chạy khi Reo
// bố cục lại. Nếu lúc đó NextUp chưa có dữ liệu (vừa đổi bài) thì hàng bị ẩn, vài giây sau dữ liệu về nhưng
// không có gì kích ReoFix tính lại -> hàng ẩn mãi. NextUp phát NUNextUpDidChangeNotification mỗi khi đổi.
@interface ReoNextUpObserver : NSObject
- (void)changed:(NSNotification *)note;
@end
static BOOL gNuPassPending = NO;
@implementation ReoNextUpObserver
- (void)changed:(NSNotification *)note {
    (void)note;
    if (gNuPassPending) return;       // gộp nhiều thông báo liên tiếp thành một lượt
    gNuPassPending = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        gNuPassPending = NO;
        UIView *c = gReoContainer;
        if (c && c.superview) ReoFixContainer(c);
    });
}
@end
static void ReoNextUpObserve(void) {
    static ReoNextUpObserver *obs = nil;
    if (obs) return;
    obs = [ReoNextUpObserver new];
    [[NSNotificationCenter defaultCenter] addObserver:obs selector:@selector(changed:)
                                                 name:@"NUNextUpDidChangeNotification" object:nil];
}

static BOOL ReoClassOwns(Class c, SEL s) {
    unsigned n = 0;
    Method *ms = class_copyMethodList(c, &n);
    BOOL r = NO;
    for (unsigned i = 0; i < n; i++) {
        if (method_getName(ms[i]) == s) { r = YES; break; }
    }
    free(ms);
    return r;
}

// Móc vào hàm chọn / bỏ chọn icon của Axon (chỉ khi lớp đó tự định nghĩa hàm này).
// Ở đây chỉ GHI NHẬN sự kiện và bật bộ bám khung hình; việc thu nhỏ/dịch lên do máy trạng thái quyết
// định dựa trên cell thông báo thật sự nhìn thấy.
static BOOL ReoSwizzleAxon(Class c, SEL s, BOOL isSelect) {
    if (!c || !ReoClassOwns(c, s)) return NO;
    Method m = class_getInstanceMethod(c, s);
    IMP orig = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^(id self_, id cv, id ip) {
        ((void (*)(id, SEL, id, id))orig)(self_, s, cv, ip);
        gAxonEventTime = CACurrentMediaTime();
        if (isSelect) gAxonTouched = YES;
        ReoLog(@"AXON %s notifOpen=%d", isSelect ? "select" : "deselect", gNotifOpen);
        ReoWatchStart();
        ReoFollow(gReoContainer, 3.0);
        if (ReoPrefBool(CFSTR("debugDump"), YES)) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)((isSelect ? 3.5 : 2.5) * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{ ReoDumpState(); });
        }
    });
    method_setImplementation(m, imp);
    return YES;
}

// Liệt kê các view liên quan tới thông báo/Axon (kể cả đang ẩn) để chẩn đoán
static void ReoDumpScan(UIView *v, int depth, NSMutableString *o, int *count) {
    if (depth < 0 || *count > 90) return;
    for (UIView *sv in v.subviews) {
        const char *n = class_getName(object_getClass(sv));
        if (n && (strstr(n, "NCNotificationListCell") || strstr(n, "NCNotificationListView") ||
                  strstr(n, "PLPlatterView") || strstr(n, "AXNView") || strstr(n, "AXNAppCell") ||
                  strstr(n, "NCNotificationShortLook"))) {
            (*count)++;
            [o appendFormat:@"   %s hidden=%d alpha=%.2f screen=%@\n", n, sv.hidden, sv.alpha,
                NSStringFromCGRect(ReoScreenRect(v, sv.frame))];
        }
        ReoDumpScan(sv, depth - 1, o, count);
    }
}

// Ghi số đo thật (toạ độ màn hình) ra /var/mobile/Documents/reofix_state.txt
static void ReoDumpState(void) {
    UIView *c = gReoContainer;
    if (!c) return;
    NSMutableString *o = [NSMutableString string];
    CGRect sb = [UIScreen mainScreen].bounds;
    ReoState rs = ReoReadState();
    [o appendFormat:@"ReoFix 0.1.7  t=%.2f\n", fmod(CACurrentMediaTime(), 100000.0)];
    [o appendFormat:@"prefs enabled=%d autoMinimize=%d hideWhenFull=%d showNextUp=%d nextUpBelow=%d liftGap=%.1f clockBottom=%.1f\n",
        ReoPrefBool(CFSTR("enabled"), YES), ReoPrefBool(CFSTR("autoMinimize"), YES), ReoPrefBool(CFSTR("hideWhenFull"), YES),
        ReoPrefBool(CFSTR("showNextUp"), YES), ReoPrefBool(CFSTR("nextUpBelow"), YES),
        ReoPrefNumber(CFSTR("liftGap"), 8), ReoPrefNumber(CFSTR("clockBottom"), 216)];
    [o appendFormat:@"screen=%@ maximized=%d lift=%@\n", NSStringFromCGSize(sb.size),
        ReoIsMaximized(c), objc_getAssociatedObject(c, kReoLiftValueKey)];
    [o appendFormat:@"lastLift want=%.1f maxLift=%.1f nTop=%.1f rowExtra=%.0f bfs=%@  autoTaps=%d watching=%d ticker=%d\n",
        gDbgWant, gDbgMaxLift, gDbgNTop, gDbgRowExtra, NSStringFromCGRect(gDbgBfs), gAutoTaps, gWatching, gTicker != nil];
    [o appendFormat:@"reoState known=%d minimized=%d dismissed=%d hiding=%d  reoImage=%d\n",
        rs.known, rs.minimized, rs.dismissed, rs.hiding, gReoHdr != NULL];
    [o appendFormat:@"flags notifOpen=%d axonTouched=%d minimizedByUs=%d\n", gNotifOpen, gAxonTouched, gMinimizedByUs];
    [o appendFormat:@"container window=%d hidden=%d alpha=%.2f\n", c.window != nil, c.hidden, c.alpha];
    UIView *root = ReoNotifRoot();
    UIView *av = ReoAxonView();
    [o appendFormat:@"notifRoot=%d (window=%d) axonView=%d (window=%d)\n", root != nil, root.window != nil,
        av != nil, av.window != nil];
    [o appendFormat:@"clockBottom=%.1f axonIcons=%@\n", ReoClockBottom(), NSStringFromCGRect(ReoAxonIconsRect())];
    CGRect u = CGRectNull;
    if (root) ReoCollectCells(root, &u, 10);
    [o appendFormat:@"notifCells=%@ notifTop=%.1f\n", NSStringFromCGRect(u), ReoNotificationTop()];
    [o appendFormat:@"container=%@\n", NSStringFromCGRect(ReoScreenFrame(c))];
    for (UIView *v in c.subviews) {
        [o appendFormat:@"  %@ hidden=%d alpha=%.2f screen=%@\n", NSStringFromClass([v class]), v.hidden, v.alpha,
            NSStringFromCGRect(ReoScreenFrame(v))];
    }
    UIView *row = objc_getAssociatedObject(c, kReoNextUpKey);
    if (row) [o appendFormat:@"nextUpRow hidden=%d screen=%@\n", row.hidden, NSStringFromCGRect(ReoScreenFrame(row))];
    [o appendString:@"-- views thong bao / Axon (ke ca dang an) --\n"];
    int count = 0;
    if (root) ReoDumpScan(root, 12, o, &count);
    [o appendString:@"-- nhat ky (cu -> moi) --\n"];
    if (gLog) [o appendString:[gLog componentsJoinedByString:@"\n"]];
    [o appendString:@"\n"];
    [o writeToFile:@"/var/mobile/Documents/reofix_state.txt" atomically:NO encoding:NSUTF8StringEncoding error:nil];

    // Toàn bộ cây view lúc đang mở thông báo (giống file cây view lần trước, nhưng chụp đúng lúc có thông báo)
    UIView *top = c.superview ? c.superview : c;
    SEL sel = NSSelectorFromString(@"recursiveDescription");
    if ([top respondsToSelector:sel]) {
        NSString *tree = ((NSString *(*)(id, SEL))objc_msgSend)(top, sel);
        [tree writeToFile:@"/var/mobile/Documents/reofix_tree_open.txt"
               atomically:NO encoding:NSUTF8StringEncoding error:nil];
    }
}

// Chỉ ghi nhận danh sách thông báo thay đổi (KHÔNG di chuyển nó), rồi cho Reo tính lại vị trí.
// Gộp nhiều lần layout trong cùng một vòng lặp thành một lần tính.
%group NotifHooks
%hook NCNotificationListView
- (void)layoutSubviews {
    %orig;
    if (gReoContainer && (gAxonTouched || gNotifOpen) && !gNotifFixPending) {
        gNotifFixPending = YES;
        dispatch_async(dispatch_get_main_queue(), ^{
            gNotifFixPending = NO;
            UIView *cc = gReoContainer;
            if (cc) ReoFixContainer(cc);
        });
    }
}
%end
%end

%hook UIView
- (void)setFrame:(CGRect)frame {
    %orig;
    if (gPassDepth == 0 && gReoContainerPtr && (__bridge void *)self.superview == gReoContainerPtr &&
        [NSThread isMainThread]) {
        ReoGuardCheck(self, frame);
    }
}
- (void)setBackgroundColor:(UIColor *)color {
    if (ReoIsMarked(self)) {
        NSMutableDictionary *d = objc_getAssociatedObject(self.layer, kReoSavedKey);
        if (color && d && CGColorGetAlpha(color.CGColor) > 0.01) d[@"bg"] = color;
        color = [UIColor clearColor];
    }
    %orig(color);
}
%end

%hook CALayer
- (void)setBackgroundColor:(CGColorRef)color {
    if (ReoIsMarked(self)) {
        NSMutableDictionary *d = objc_getAssociatedObject(self, kReoSavedKey);
        if (color && d && !d[@"bg"] && CGColorGetAlpha(color) > 0.01) {
            d[@"lbg"] = [UIColor colorWithCGColor:color];
        }
        color = NULL;
    }
    %orig(color);
}
- (void)setBorderWidth:(CGFloat)w {
    if (ReoIsMarked(self)) {
        NSMutableDictionary *d = objc_getAssociatedObject(self, kReoSavedKey);
        if (d && w > 0) d[@"bw"] = @(w);
        w = 0;
    }
    %orig(w);
}
%end

// Đổi bài mà container không layout lại -> vẫn cập nhật khi ảnh đổi
%hook UIImageView
- (void)setImage:(UIImage *)image {
    %orig;
    ReoWeakBox *b = objc_getAssociatedObject(self, kReoBoxKey);
    UIView *c = b.v;
    if (c) {
        dispatch_async(dispatch_get_main_queue(), ^{ ReoFixContainer(c); });
    }
}
%end

%group ReoHooks
%hook ReoContainerView
// Vùng trống của container Reo không được chặn thao tác chạm: cho chạm xuyên xuống
// các view bên dưới (icon/danh sách thông báo của tweak thông báo, v.v.)
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    // Các view con được dịch NHÌN THẤY lên `lift` pt (sublayerTransform) mà frame vẫn ở chỗ cũ,
    // nên điểm chạm phải quy về toạ độ gốc: cộng lại `lift`.
    CGFloat lift = [objc_getAssociatedObject(self, kReoLiftValueKey) doubleValue];
    if (fabs(lift) > 0.5) point.y += lift;   // lift < 0: player đang ẩn dưới đáy -> cú chạm không rơi vào view vô hình
    UIView *hit = %orig(point, event);
    return (hit == self) ? nil : hit;
}
// View con nằm ra ngoài bounds của container (player đã dịch lên, hàng Next Up nằm dưới khung ở chế độ
// thu nhỏ) thì UIKit không chuyển cú chạm xuống chúng. Mở rộng vùng chạm theo frame các view con;
// vùng trống vẫn xuyên qua nhờ hitTest ở trên.
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    if (%orig) return YES;
    for (UIView *v in self.subviews) {
        if (v.hidden || v.alpha < 0.01 || !v.userInteractionEnabled) continue;
        if (CGRectContainsPoint(v.frame, point)) return YES;
    }
    return NO;
}
- (void)layoutSubviews {
    %orig;
    ReoFixContainer(self);
}
- (void)didMoveToWindow {
    %orig;
    ReoFixContainer(self);
}
%end
%end

static BOOL gInitReo = NO, gInitNotif = NO, gInitAxon = NO;

static void ReoTryInitMisc(void) {
    if (!gInitNotif && objc_getClass("NCNotificationListView")) {
        gInitNotif = YES;
        %init(NotifHooks);
        ReoLog(@"init: NCNotificationListView hook ok");
    }
    if (!gInitAxon) {
        BOOL any = NO;
        for (NSString *cn in @[@"AXNView", @"AXNManager"]) {
            Class c = NSClassFromString(cn);
            if (!c) continue;
            if (ReoSwizzleAxon(c, @selector(collectionView:didSelectItemAtIndexPath:), YES)) any = YES;
            if (ReoSwizzleAxon(c, @selector(collectionView:didDeselectItemAtIndexPath:), NO)) any = YES;
        }
        if (any) {
            gInitAxon = YES;
            ReoLog(@"init: Axon select/deselect hook ok");
        }
    }
}

static void ReoTryInit(void) {
    if (gInitReo || !objc_getClass("ReoContainerView")) return;
    gInitReo = YES;
    %init(ReoHooks);
    ReoLog(@"init: ReoContainerView hook ok");
}

// Reo/Axon có thể nạp muộn hơn ReoFix: thử lại ở 5, 15, 40 giây cho tới khi đủ cả ba
static void ReoInitRetry(int n) {
    ReoTryInit();
    ReoTryInitMisc();
    if (gInitReo && gInitNotif && gInitAxon) return;
    if (n >= 3) {
        ReoLog(@"init: THIEU reo=%d notif=%d axon=%d", gInitReo, gInitNotif, gInitAxon);
        return;
    }
    double delays[3] = {5, 10, 25};
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delays[n] * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ ReoInitRetry(n + 1); });
}

%ctor {
    %init;
    ReoLog(@"ReoFix 0.1.7 loaded");
    ReoTryInit();
    ReoTryInitMisc();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC),
                   dispatch_get_main_queue(), ^{ ReoInitRetry(0); });
}
